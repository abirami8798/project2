import { Component, OnInit, Input } from '@angular/core';
import { User } from '../user';
import { ViewuserComponent } from '../viewuser/viewuser.component';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {

  @Input() user:User
  constructor(private viewuser:ViewuserComponent,private userservice:UserService) { }

  ngOnInit() {
  }

}
