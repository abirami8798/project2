export class Skill {
    id:number;
    name:string;
    TOC:string;
    duration:string;
    prerequites:string;
}
