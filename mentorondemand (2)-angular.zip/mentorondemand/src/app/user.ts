

export class User {
    id:number;
    userName:String;
    password:String;
    emailId:String;
    contactNumber:number;
    regCode:number;
    regDatetime:Date;
    active:boolean;
}
