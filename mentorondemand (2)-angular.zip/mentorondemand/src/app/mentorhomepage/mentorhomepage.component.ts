import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorhomepage',
  templateUrl: './mentorhomepage.component.html',
  styleUrls: ['./mentorhomepage.component.css']
})
export class MentorhomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
