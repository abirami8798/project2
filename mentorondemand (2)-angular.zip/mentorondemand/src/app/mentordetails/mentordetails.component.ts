import { Component, OnInit, Input } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';
import { MentorlistComponent } from '../mentorlist/mentorlist.component';
import { AdminactionListComponent } from '../adminaction-list/adminaction-list.component';

@Component({
  selector: 'app-mentordetails',
  templateUrl: './mentordetails.component.html',
  styleUrls: ['./mentordetails.component.css']
})
export class MentordetailsComponent implements OnInit {

  @Input() mentor : Mentor;
  constructor(private mentorservice:MentorService,private mentorlist:MentorlistComponent) { }

  ngOnInit() {
  }

}
