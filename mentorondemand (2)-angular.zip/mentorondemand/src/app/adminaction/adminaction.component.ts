import { Component, OnInit, Input } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';
import { AdminactionListComponent } from '../adminaction-list/adminaction-list.component';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-adminaction',
  templateUrl: './adminaction.component.html',
  styleUrls: ['./adminaction.component.css']
})
export class AdminactionComponent implements OnInit {

  @Input() mentor : Mentor;
  
  mentors:Observable<Mentor[]>;
  constructor( private mentorservice:MentorService,private adminactionlist:AdminactionListComponent,private route:Router) { }

  ngOnInit() {

  }

  deleteMentor() {
    this.mentorservice.deleteMentor(this.mentor.id)
      .subscribe(
        (data) => {
          console.log(data);
          this.adminactionlist.getData();
        },
        error => console.log(error));
  }

 updateMentor(){
   this.mentorservice.updateMentor(this.mentor.id,
    { username:this.mentor.username,password:this.mentor.password,linkedUrl:this.mentor.linkedUrl,
      regDatetime:this.mentor.regDatetime,regCode:this.mentor.regCode,yearOfExperience:this.mentor.yearOfExperience,
      active:this.mentor.active,selfRating:this.mentor.selfRating,skill:this.mentor.skill,email:this.mentor.skill,
      contactNumber:this.mentor.contactNumber})
      .subscribe(
        (data:Mentor)=>{
          console.log(data);
          this.mentor=data;
          this.mentorservice.mentor=data;
        },
        error=>console.log(error));
 }

 
 updatePage(){
   //this.updateMentor();
   this.route.navigate(['/updatementor']);
 }
}
