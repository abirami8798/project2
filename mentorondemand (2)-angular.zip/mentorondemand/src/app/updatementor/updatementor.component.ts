import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-updatementor',
  templateUrl: './updatementor.component.html',
  styleUrls: ['./updatementor.component.css']
})
export class UpdatementorComponent implements OnInit {

  mentor:Mentor;
  constructor( private mentorservice:MentorService) { }

  ngOnInit() {
    this.mentor=this.mentorservice.mentor;
  }
}
