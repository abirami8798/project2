import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { MentorComponent } from './mentor/mentor.component';
import { AdminComponent } from './admin/admin.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { from } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { MentorhomepageComponent } from './mentorhomepage/mentorhomepage.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { MentordetailsComponent } from './mentordetails/mentordetails.component';
import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { AdminactionComponent } from './adminaction/adminaction.component';
import { AdminactionListComponent } from './adminaction-list/adminaction-list.component';
import { UpdatementorComponent } from './updatementor/updatementor.component';
import { UserComponent } from './user/user.component';
import { SkillComponent } from './skill/skill.component';
import { Skill } from './skill';
import { ViewuserComponent } from './viewuser/viewuser.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    HeaderComponent,
    MentorComponent,
    AdminComponent,
    UserhomepageComponent,
    HomepageComponent,
    MentorhomepageComponent,
    AdminhomepageComponent,
    MentordetailsComponent,
    MentorlistComponent,
    AdminactionComponent,
    AdminactionListComponent,
    UpdatementorComponent,
    UserComponent,
    SkillComponent,
    ViewuserComponent,
    UserdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path:'',component:UserLoginComponent},
      {path:'admin',component:AdminComponent},
      {path:'mentor',component:MentorComponent},
      {path:'homepage',component:HomepageComponent},
      {path:'userhomepage',component:UserhomepageComponent},
      {path:'adminhomepage',component:AdminhomepageComponent},
      {path:'mentorhomepage',component:MentorhomepageComponent},
      {path:'mentorlist',component:MentorlistComponent},
      {path:'mentordetails',component:MentordetailsComponent},
      {path:'adminaction',component:AdminactionComponent},
      {path:'adminactionlist',component:AdminactionListComponent},
      {path:'updatementor',component:UpdatementorComponent},
      {path:'addskill',component:SkillComponent},
      {path:'userlist',component:ViewuserComponent},
      {path:'userdetails',component:UserdetailsComponent}

    ]),
    FormsModule,
    HttpClientModule,
    AppRoutingModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
