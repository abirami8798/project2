import { Component, OnInit } from '@angular/core';
import { observable, Observable } from 'rxjs';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {

  users:Observable<User[]>;

  constructor( private userservice:UserService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers(){
    this.users=this.userservice.getUser();
  }
}
