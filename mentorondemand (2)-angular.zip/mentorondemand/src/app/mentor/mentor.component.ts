import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {


  mentor: Mentor = new Mentor();
  username:string;
  password:string;
  submitted = false;

  constructor(private mentorservice: MentorService,private route:Router) { }

  ngOnInit() {
     

  }

  newMentor(): void {
    this.submitted = false;
    this.mentor = new Mentor();
  }

  save() {
    this.mentorservice.createMentor(this.mentor)
      .subscribe(data => console.log(data), error => console.log(error));
    this.mentor = new Mentor();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  mentor1:Mentor

  onLogin(){
    console.log("dsfds");
    console.log(this.mentor.username);
    this.mentorservice.searchMentor(this.mentor.username,this.mentor.password).subscribe(
      (mentor:Mentor)=>{
        console.log(mentor.username);
        if(mentor!=null)
        {
          this.createUser(mentor);
          this.route.navigate([('mentorlist')])
        }
        else{
          this.route.navigate([('mentor')]);
        }
      }
    );
     
  }
  

createUser(mentor:Mentor){
  this.mentor1=mentor;
window.localStorage.setItem("mentor",this.mentor.username);

}
 

}
