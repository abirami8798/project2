import { Injectable, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Mentor } from './mentor';
import { AdminactionListComponent } from './adminaction-list/adminaction-list.component';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl = 'http://localhost:4567/api/mentor';

 
   mentor:Mentor;
  constructor(private  http:HttpClient,private mentorservice:MentorService) { }

  createMentor(mentor: Object): Observable<Object> {
    return this.http.post(`${this. baseUrl}` + `/register`,mentor);
  }

  getMentorList():Observable<any>{
    return this.http.get(`${this.baseUrl}`);
  }

  deleteMentor(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  updateMentor(id:number,value:any){
    return this.http.post(`${this.baseUrl}/${id}`,value);
  }

  searchMentor(username:string,password:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/${username}/${password}`);
  }

}


