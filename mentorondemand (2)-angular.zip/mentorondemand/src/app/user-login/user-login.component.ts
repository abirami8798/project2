import { Component, OnInit } from '@angular/core';
import '../scripts/userlogin.js'

import { UserService } from '../user.service.js';
import { User } from '../user.js';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
 submitted=false;
  user:User=new User();
  constructor(private userservice:UserService) { }

  ngOnInit() {
  }
saveUser(){
  this.userservice.createUser(this.user)
  .subscribe(data => console.log(data), error => console.log(error));
    this.user = new User();
}

  onSubmit(){
    this.submitted=true;
    this.saveUser();

  }

}
