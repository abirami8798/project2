import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminactionListComponent } from './adminaction-list.component';

describe('AdminactionListComponent', () => {
  let component: AdminactionListComponent;
  let fixture: ComponentFixture<AdminactionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminactionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminactionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
