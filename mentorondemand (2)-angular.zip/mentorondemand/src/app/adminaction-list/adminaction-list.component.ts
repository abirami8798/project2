import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-adminaction-list',
  templateUrl: './adminaction-list.component.html',
  styleUrls: ['./adminaction-list.component.css']
})
export class AdminactionListComponent implements OnInit {

  mentors:Observable<Mentor[]>;
  
  constructor( private mentorservice:MentorService) { }

  
  ngOnInit() {
    this.getData();
  }

  getData(){
    this.mentors=this.mentorservice.getMentorList();
  }

}
