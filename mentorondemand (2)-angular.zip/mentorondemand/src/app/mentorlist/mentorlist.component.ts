import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentorlist',
  templateUrl: './mentorlist.component.html',
  styleUrls: ['./mentorlist.component.css']
})
export class MentorlistComponent implements OnInit {

  mentors:Observable<Mentor[]>;
  constructor( private mentorservice:MentorService) { }

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.mentors=this.mentorservice.getMentorList();
  }

}
