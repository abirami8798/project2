import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = 'http://localhost:4567/api/user';
  constructor(private  http:HttpClient,private userservice:UserService) { }
  

user :User
createUser(user:object):Observable<object>{
  return this.http.post(`${this.baseUrl}`+`/register`,user);
}


getUser():Observable<any>{
  return this.http.get(`${this.baseUrl}`);
}
}