export class Mentor {
    id:number;
    username:string
    email:string;
    password:string;
    contactNumber:number;
    linkedUrl:string;
    regDatetime:Date;
    regCode:number;
    skill:string;
    selfRating:number;
    yearOfExperience:number;
    active:boolean;
   
}
