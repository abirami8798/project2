package com.example.mentor_on_demand.service;
import org.springframework.data.repository.CrudRepository;


import com.example.mentor_on_demand.model.User;
public interface UserRepository extends CrudRepository<User, Long> {
	

}
