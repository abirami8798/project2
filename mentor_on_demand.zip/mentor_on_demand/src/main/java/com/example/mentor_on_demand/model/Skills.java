package com.example.mentor_on_demand.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="skills")
public class Skills {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@Column(name="name")
	private String name;
	@Column(name="TOC")
	private String TOC;
	@Column(name="duration")
	private String duration;
	@Column(name="prerequites")
	private String prerequites;
	public Skills() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Skills(long id, String name, String tOC, String duration, String prerequites) {
		super();
		this.id = id;
		this.name = name;
		TOC = tOC;
		this.duration = duration;
		this.prerequites = prerequites;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((TOC == null) ? 0 : TOC.hashCode());
		result = prime * result + ((duration == null) ? 0 : duration.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((prerequites == null) ? 0 : prerequites.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Skills other = (Skills) obj;
		if (TOC == null) {
			if (other.TOC != null)
				return false;
		} else if (!TOC.equals(other.TOC))
			return false;
		if (duration == null) {
			if (other.duration != null)
				return false;
		} else if (!duration.equals(other.duration))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (prerequites == null) {
			if (other.prerequites != null)
				return false;
		} else if (!prerequites.equals(other.prerequites))
			return false;
		return true;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTOC() {
		return TOC;
	}
	public void setTOC(String tOC) {
		TOC = tOC;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getPrerequites() {
		return prerequites;
	}
	public void setPrerequites(String prerequites) {
		this.prerequites = prerequites;
	}
	@Override
	public String toString() {
		return "Skills [id=" + id + ", name=" + name + ", TOC=" + TOC + ", duration=" + duration + ", prerequites="
				+ prerequites + "]";
	}
	

}
