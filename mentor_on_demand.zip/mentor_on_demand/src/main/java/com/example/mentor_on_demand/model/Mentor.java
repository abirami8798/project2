package com.example.mentor_on_demand.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor")
public class Mentor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "user_name")
	private String username;
	@Column(name = "password")
	private String password;
	@Column(name = "linked_url")
	private String linkedUrl;
	@Column(name = "reg_datetime")
	private Date regDatetime;
	@Column(name = "reg_code")
	private int regCode;
	@Column(name = "year_of_experience")
	private int yearOfExperience;
	@Column(name = "active")
	private boolean active;
	@Column(name = "self_rating")
	private int selfRating;
	@Column(name = "skill")
	private String skill;
	@Column(name = "email")
	private String email;
	@Column(name="contact_number")
	private long contactNumber;
	public Mentor() {
		super();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLinkedUrl() {
		return linkedUrl;
	}
	public void setLinkedUrl(String linkedUrl) {
		this.linkedUrl = linkedUrl;
	}
	public Date getRegDatetime() {
		return regDatetime;
	}
	public void setRegDatetime(Date regDatetime) {
		this.regDatetime = regDatetime;
	}
	public int getRegCode() {
		return regCode;
	}
	public void setRegCode(int regCode) {
		this.regCode = regCode;
	}
	public int getYearOfExperience() {
		return yearOfExperience;
	}
	public void setYearOfExperience(int yearOfExperience) {
		this.yearOfExperience = yearOfExperience;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public int getSelfRating() {
		return selfRating;
	}
	public void setSelfRating(int selfRating) {
		this.selfRating = selfRating;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Mentor(String username, String password, String linkedUrl, Date regDatetime, int regCode,
			int yearOfExperience, boolean active, int selfRating, String skill, String email, long contactNumber) {
		super();
		this.username = username;
		this.password = password;
		this.linkedUrl = linkedUrl;
		this.regDatetime = regDatetime;
		this.regCode = regCode;
		this.yearOfExperience = yearOfExperience;
		this.active = active;
		this.selfRating = selfRating;
		this.skill = skill;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + (int) (contactNumber ^ (contactNumber >>> 32));
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((linkedUrl == null) ? 0 : linkedUrl.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + regCode;
		result = prime * result + ((regDatetime == null) ? 0 : regDatetime.hashCode());
		result = prime * result + selfRating;
		result = prime * result + ((skill == null) ? 0 : skill.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		result = prime * result + yearOfExperience;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mentor other = (Mentor) obj;
		if (active != other.active)
			return false;
		if (contactNumber != other.contactNumber)
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id != other.id)
			return false;
		if (linkedUrl == null) {
			if (other.linkedUrl != null)
				return false;
		} else if (!linkedUrl.equals(other.linkedUrl))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (regCode != other.regCode)
			return false;
		if (regDatetime == null) {
			if (other.regDatetime != null)
				return false;
		} else if (!regDatetime.equals(other.regDatetime))
			return false;
		if (selfRating != other.selfRating)
			return false;
		if (skill == null) {
			if (other.skill != null)
				return false;
		} else if (!skill.equals(other.skill))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		if (yearOfExperience != other.yearOfExperience)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Mentor [id=" + id + ", username=" + username + ", password=" + password + ", linkedUrl=" + linkedUrl
				+ ", regDatetime=" + regDatetime + ", regCode=" + regCode + ", yearOfExperience=" + yearOfExperience
				+ ", active=" + active + ", selfRating=" + selfRating + ", skill=" + skill + ", email=" + email
				+ ", contactNumber=" + contactNumber + "]";
	}
	
	
}
