package com.example.mentor_on_demand.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mentor_on_demand.model.Mentor;
import com.example.mentor_on_demand.service.MentorRepository;



@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api")
public class MentorController {

	@Autowired
	MentorRepository mentorrepo;

	@PostMapping("/mentor/register")
	public Mentor saveMentor(@RequestBody Mentor mentor) {
		System.out.println(mentor.isActive());
		Mentor mentor2 = mentorrepo.save(new Mentor(mentor.getUsername(), mentor.getPassword(), mentor.getLinkedUrl(),
				mentor.getRegDatetime(), mentor.getRegCode(), mentor.getYearOfExperience(), mentor.isActive(),
				mentor.getSelfRating(), mentor.getSkill(), mentor.getEmail(), mentor.getContactNumber()));
		return mentor2;
	}
	

	@GetMapping("/mentor")
	public List<Mentor> getMentorsList(){
	  List<Mentor> mentor=new ArrayList<Mentor>();
	  mentorrepo.findAll().forEach(mentor::add);
	  return mentor;
	}


	
	@DeleteMapping("/mentor/{id}")
	public ResponseEntity<String> deleteById(@PathVariable("id") int id){
		mentorrepo.deleteById((long) id);
		
		return new ResponseEntity<String>("mentor is deleted",HttpStatus.OK);
		
	}
	
	@GetMapping("/mentor/{username}/{password}")
	public Mentor checkLogin(@PathVariable("username") String username,@PathVariable("password") String password) {
		System.out.println(username);
		System.out.println(password);
		Mentor mentor=new Mentor();
		mentor=mentorrepo.mentorLogin(username, password);
		return mentor;
		
	}
	

	@PutMapping("/mentor/{id}")
	public Mentor updateMentor(@PathVariable("id") long id,@RequestBody Mentor mentor){
		Optional<Mentor> menOptional=mentorrepo.findById(id);
		Mentor mentor2=menOptional.get();
		mentor2.setUsername(mentor.getUsername());
		mentor2.setActive(mentor.isActive());
		mentor2.setContactNumber(mentor.getContactNumber());
		mentor2.setYearOfExperience(mentor.getYearOfExperience());
		mentor2.setSelfRating(mentor.getSelfRating());
		mentor2.setEmail(mentor.getEmail());
		mentor2.setLinkedUrl(mentor.getLinkedUrl());
		mentor2.setRegCode(mentor.getRegCode());
		mentor2.setRegDatetime(mentor.getRegDatetime());
		mentor2.setPassword(mentor.getPassword());
		mentor2.setSkill(mentor.getSkill());
		mentorrepo.save(mentor2);
		System.out.println(mentor2);
		return mentor2;
	}
}
