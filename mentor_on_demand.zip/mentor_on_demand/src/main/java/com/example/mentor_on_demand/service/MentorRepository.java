package com.example.mentor_on_demand.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import com.example.mentor_on_demand.model.Mentor;


public interface MentorRepository extends CrudRepository<Mentor, Long> {
	
@Query("select m from Mentor m where m.id= :id")
public List<Mentor> findById(@Param("id")int id);

@Query("select m from Mentor m where m.username= :username and m.password= :password")
public Mentor mentorLogin(@Param("username") String username,@Param("password") String password);

}
