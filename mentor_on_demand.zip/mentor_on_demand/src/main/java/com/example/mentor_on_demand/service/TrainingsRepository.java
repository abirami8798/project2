package com.example.mentor_on_demand.service;

import java.util.List;
import java.util.Optional;

import com.example.mentor_on_demand.model.Trainings;

public interface TrainingsRepository {
	public List<Trainings> getAllCustomers();
	public List<Trainings> getCompletedTrainings();
	public Iterable<Trainings> findAll();
	public Trainings save(Trainings trainings);
	public Optional<Trainings> findById(long id);
	public void findCompletedTrainings(String string); 

}
